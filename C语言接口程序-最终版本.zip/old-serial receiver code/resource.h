//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by 66.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MY66_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       130
#define IDC_MSCOMM1                     1000
#define IDC_BUTTON_MANUALSEND           1001
#define IDC_EDIT_RXDATA                 1005
#define IDC_EDIT_TXDATA                 1006
#define IDC_CHECK_HEXSEND               1008
#define IDC_CHECK_HEXDISPLAY            1009
#define IDC_BUTTON_START                1010
#define IDC_BUTTON_STOP                 1011
#define IDC_EDIT_PORTNO                 1012
#define IDC_EDIT_SAVEPATH               1013
#define IDC_BUTTON_SAVEPATH             1014
#define IDC_BUTTON_CLOSE                1015
#define IDC_STATIC_ENDFLAG              1016
#define IDC_EDIT_ENDFLAG                1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
